<?php
namespace Eventin;

/**
 * Class Installer
 * 
 * @package Eventin
 */
class Installer {
    /**
     * Run installer
     *
     * @return  void
     */
    public static function run(): void {
        // todo: Add plugin installer logic.
    }
}
