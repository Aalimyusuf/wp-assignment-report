<?php
/**
 * Register Custom Role
 *
 * @package Eventin
 */
namespace Etn\Base;

/**
 * Abstract Class Role
 *
 * @package Eventin\Base
 */
abstract class Role {


    /**
     * Initialize
     *
     * @return void
     */
    public function init() {}

}
