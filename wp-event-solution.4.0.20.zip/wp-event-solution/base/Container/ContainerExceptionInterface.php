<?php

namespace Eventin\Container;

/**
 * Base interface representing a generic exception in a container.
 *
 * @package PhpKnight\WeMeal\Container
 */
interface ContainerExceptionInterface {
}
