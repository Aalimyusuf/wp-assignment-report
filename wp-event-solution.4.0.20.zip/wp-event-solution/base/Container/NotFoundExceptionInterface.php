<?php

namespace Eventin\Container;

/**
 * No entry was found in the container.
 *
 * @package PhpKnight\WeMeal\Container
 */
interface NotFoundExceptionInterface {
}
