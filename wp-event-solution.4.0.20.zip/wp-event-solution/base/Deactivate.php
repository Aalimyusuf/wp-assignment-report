<?php
namespace Eventin;

/**
 * Class Deactivation
 * 
 * @package Eventin
 */
class Deactivate {
    // todo: Add deactivation logic.
}
