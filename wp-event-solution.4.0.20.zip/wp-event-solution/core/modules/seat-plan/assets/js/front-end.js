jQuery(document).ready(function ($) {
	"use strict";
	// const seatPlan = document.getElementById("etn-checkout-button");
	// if (seatPlan) {
		// seatPlan.addEventListener("checkOutButtonEvent", function (event) {
			// event.preventDefault();
			// console.log(event.detail);
			// $(".variation_picked_total_qty").val(event?.detail?.ticketQuantity);
			// $(".etn_total_price").val(event?.detail?.ticketPrice);
			// $(".etn_total_qty").val(event?.detail?.ticketQuantity);
		// });
	// }
});
