<?php

use \Etn\Utils\Helper;
use Etn\Templates\Event\Parts\EventDetailsParts;

defined( 'ABSPATH' ) || exit;

EventDetailsParts::event_single_tag_list( $single_event_id );