<?php

use \Etn\Utils\Helper;
use Etn\Templates\Event\Parts\EventDetailsParts;

defined( 'ABSPATH' ) || exit;

EventDetailsParts::event_single_category( $single_event_id );
