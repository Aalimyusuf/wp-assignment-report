<?php
defined( 'ABSPATH' ) || exit;

if ( !empty( $topic ) ) {
    ?>
        <h4 class="etn-title"><?php echo esc_html( $topic ); ?></h4>
    <?php
}